python3 send.py -g 21 -t 1 -p 282 7059746
